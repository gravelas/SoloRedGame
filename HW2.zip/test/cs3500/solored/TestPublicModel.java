package cs3500.solored;

import org.junit.Test;

public class TestPublicModel {

  @Test
  public void testViewToString() {

  }
}
